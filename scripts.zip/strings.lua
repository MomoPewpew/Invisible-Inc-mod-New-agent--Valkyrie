local MOD_STRINGS =
{
	OPTIONS =
	{
		OF_RESCUABLE = "VALKYRIE RESUABLE",
		OF_RESCUABLE_DESC = "Whether On-File Valkyrie can be rescued from a Detention Center",
	},
	AGENTS =
	{
		VALKYRIE =
		{
			NAME = "Valkyrie",
			FILE = "",
			YEARS_OF_SERVICE = "",
			AGE = "",
			HOMETOWN = "",
			RESCUED = "",
			BANTER = "",
			ALT_1 =
			{
				FULLNAME = "",
				TOOLTIP = "",
				BIO = "",
			},
		},
	},
}

return MOD_STRINGS